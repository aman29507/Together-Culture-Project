function redirectToLogin() {
    window.location.href = "login.html";
}
